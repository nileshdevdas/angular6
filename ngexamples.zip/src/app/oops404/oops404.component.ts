import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oops404',
  templateUrl: './oops404.component.html',
  styleUrls: ['./oops404.component.css']
})
export class Oops404Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
