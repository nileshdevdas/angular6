import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SearchComponent } from './search/search.component';
import { Oops404Component } from './oops404/oops404.component';
import { DetailsComponent } from './details/details.component';
import { CallbackComponent } from './callback/callback.component';
import { MycompComponent } from './mycomp/mycomp.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule } from '@angular/forms'
export const routes = [
  { path: '', component: HomeComponent },
  { path: 'details', component: DetailsComponent },
  { path: 'search', component: SearchComponent },
  { path: 'callback', component: CallbackComponent },
  { path: '**', component: Oops404Component }
]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    Oops404Component,
    DetailsComponent,
    HomeComponent,
    SearchComponent,
    CallbackComponent,
    MycompComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
