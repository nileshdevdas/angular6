import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MycompComponent } from './mycomp.component';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { routes } from '../app.module';
import { HomeComponent } from '../home/home.component';
import { SearchComponent } from '../search/search.component';
import { DetailsComponent } from '../details/details.component';
import { CallbackComponent } from '../callback/callback.component';
import { Oops404Component } from '../oops404/oops404.component';
import { APP_BASE_HREF } from '@angular/common';

describe('MycompComponent', () => {
  let component: MycompComponent;
  let fixture: ComponentFixture<MycompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MycompComponent, HomeComponent, SearchComponent, DetailsComponent, CallbackComponent, Oops404Component],
      imports: [RouterModule.forRoot(routes)],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MycompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('title should be', () => {
    expect(component.title == "MyComp").toBeTruthy();
  })

  it("should inject service", () => {
    expect(component.auth).toBeTruthy;
  });

  it("Check Service Instance", () => {
    expect(component.auth.auth0).toBeTruthy();
  });

});
